function Hello() {
  return <h1> Hello from a component</h1>;
}

export default Hello;
